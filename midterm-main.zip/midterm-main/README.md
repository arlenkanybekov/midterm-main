# Exam on Introduction to engineering and computer science

#### Make a fork of this repository on your GitHab. Read the tasks carefully and complete them according to the instructions.



✔️ *All tasks must be done on the git and uploaded to the GitHub.* 

✔️ *Send me a link to your GitHub repository with the completed tasks in a telegram message: @AntigravityApple.*

✔️ *In the next message after the link send me information about who you are: name, surname and group.*

⚠️   *Don't do Pull request.* 

⚠️   *Your push operation may not work. If so you can use FORCE PUSH. How to do force push you can find in internet, or use https url.* 

⚠️ *The end of the exam is at **11:30**.* 

❌ *I will not accept links that are sent later than end of the exam*  

❌  *I will not accept a links if you send me your GitHub instead of a repository with answers.*

❌ *I will not accept links unless you post information about who you are.*
## 

 ## Tasks:

**Task 1️⃣:** Delete the last three commits.

**Task 2️⃣:** You need to explain how the Git Revert command works. Create a TXT file in this repository. Name it Task_2 and write the answer to the question in it. Make a commit with a clear name.

**Task 3️⃣:** Make ignoring of git of 1 any file and 1 any folder.

**Task 4️⃣:** Switch to the fourth commit. Find the file with the question. Switch back to the latest commit of your main branch. Create a TXT file in the same repository on the main branch. Name it Question_1 and write the answer to the question into it. Make a commit with a clear name.

**Task 5️⃣:** Explain how the commands from chapter 6 work. Write the answer to the file "Answer_6". Make a commit.

**Task 6️⃣:** Delete the deadfox file. Make a commit.

**Task 7️⃣:** Switch to any commit. Take a screenshot of logs. Switch back without creating new branches. Save the screenshot and make commit.